# ARCS-LSAM-CSUN-openCAESAR  
## Implementing [openCAESAR](https://github.com/opencaesar) to create an ontology  
```
git clone  https://github.com/RuitaoWu/ARCS-LSAM-CSUN-openCAESAR.git  
cd ARCS-LSAM-CSUN-openCAESAR
gradle build  
``` 
### only support JDK 11  
### The Flowchart that used to create an ontology (Fixed the low pixel issue)  
![Flowchart](https://github.com/RuitaoWu/ARCS-LSAM-CSUN-openCAESAR/blob/main/image/uml.jpg)  